namespace DualPantoToolkit
{
    public enum IntroContourStrategy
    {
        WALL_SCRATCH_SOUND,
        SYNC_WORDS_WITH_MOVEMENT
    }
}
