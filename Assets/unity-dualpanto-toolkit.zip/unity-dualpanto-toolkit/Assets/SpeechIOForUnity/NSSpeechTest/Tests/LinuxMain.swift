import XCTest

import NSSpeechTestTests

var tests = [XCTestCaseEntry]()
tests += NSSpeechTestTests.allTests()
XCTMain(tests)
